import json
import os
import requests
from bs4 import BeautifulSoup
from flask import Flask, render_template, session, request
app = Flask('__name__')

app.config['token_url'] = 'https://entitlement-qa.gcs.int.thomsonreuters.com/v1/token'
app.config['client_secret'] = 'kZpTrDSsi0fkP30'
app.config['client_id'] = '4d801f4f-2361-4b6e-b4a2-4d087ef16a8b'
app.config['service_api'] = 'https://contentresource-qa.gcs.int.thomsonreuters.com/v1/renditions/{}/service-output?serviceType=Classification'
app.config['task_api'] = 'https://mlannotation-qa.gcs.int.thomsonreuters.com/v1/annotations/0c52eb3c-0919-4c07-8af0-42c84aee8466'
app.config['norm_api'] = 'https://contentresource-qa.gcs.int.thomsonreuters.com/v3/renditions/{}/data'
app.config['token'] = ''
app.config['rendition_guid'] = ''


# Aws Lambda function
def lambda_handler(event, context):
    print(event)
    item = list(map(lambda x: x['detail']['item'], event['inputData']))
    print("item List :", item)
    consumer_key = os.getenv('consumer_key')
    consumer_secret = os.getenv('consumer_secret')
    entitlement_url = os.getenv('entitlement_url')
    storage_url = os.getenv('storage_url')
    access_token = get_jwt_token(consumer_key, consumer_secret, entitlement_url)
    print("Response from entitlement: ", access_token)
    for listID in list:
        print("listID: ", listID)
        response = get_storage_service(access_token, storage_url, listID)
        print("Response from storage: ", response.text)

    return "Success"


# Generating Jwt token
@app.route('/token', methods=['POST'])
def get_jwt_token():

    data = 'grant_type=client_credentials&client_id=' + app.config['client_id'] + '&client_secret=' + app.config['client_secret']
    header = {"Content-type": "application/x-www-form-urlencoded"}
    try:
        response = requests.post(app.config['token_url'], data=data, headers=header)
        access_token = json.loads(response.text)
        final_response = access_token['access_token']
        app.config['token'] = final_response
        app.config['rendition_guid'] = request.form['renditionGuid']

    except requests.exceptions as err:
        print(err)
        final_response = 'error'

    return final_response


# API Response
@app.route('/response')
def get_storage_service():

    jwt_token = app.config['token']
    rendition_guid = app.config['rendition_guid']

    # Preparing Token format
    headers_api = {
        'Authorization': 'Bearer ' + jwt_token
    }

    try:
        # Normalization API
        norm_url = app.config['norm_api'].format(str(rendition_guid))
        norm_response = requests.get(url=norm_url, headers=headers_api)
        text = norm_response.content

        # make a soup object by using
        # beautiful soup and set the markup as html parser
        soup = BeautifulSoup(text, "html.parser")

        # Service API
        service_url = app.config['service_api'].format(str(rendition_guid))
        # Service API response
        response = requests.get(url=service_url, headers=headers_api)
        print("Response Status code --->", response)
        for item in response.json():

            return render_template('./index.html', title="Classification", jsonfile=json.dumps(item), content=str(soup.prettify()))

    except requests.exceptions as err:
        print(err)
        response = 'error'
        return response


# Home
@app.route('/')
def home():
    if not session.get('logged_in'):
        return render_template('login.html')
    else:
        return 'Logged in currently'


if __name__ == '__main__':

    app.run(debug=True)

    # access_token = get_jwt_token()
    # #print(access_token)
    # get_storage_service()
