# Authorization data

import base64
import requests

username = 'venkatesh.n2@thomsonreuters.com'
password = 'Welcome@2021'
client_id = '4d801f4f-2361-4b6e-b4a2-4d087ef16a8b'
client_secret = 'kZpTrDSsi0fkP30'
grant_type = client_id+"&"+client_secret
consumer_key_secret_enc = base64.b64encode(grant_type.encode()).decode()

grant_type = "client_credentials&client_id&client_secret"

# Your decoded key will be something like:
#zzRjettzNUJXbFRqWENuuGszWWllX1iiR0VJYTpRelBLZkp5a2l2V0xmSGtmZ1NkWExWzzhDaWdh


headersAuth = {
    'Authorization': 'Bearer' + str(grant_type),

}

data = {
  'username': username,
  'password': password,
  'content-type': "application/x-www-form-urlencoded"
}
import pdb;pdb.set_trace()
## Authentication request

response = requests.post('https://entitlement-qa.gcs.int.thomsonreuters.com/v1/token', headers=headersAuth, data=data, verify=True)
jobj = response.json()

# When you print that response you will get dictionary like this:

{
    "access_token": "zz8d62zz-56zz-34zz-9zzf-azze1b8057f8",
    "refresh_token": "zzazz4c3-zz2e-zz25-zz97-ezz6e219cbf6",
    "scope": "default",
    "token_type": "Bearer",
    "expires_in": 3600
}

# You have to use `access_token` in API calls explained bellow.
# You can get `access_token` with j['access_token'].


# Using authentication to make API calls

## Define header for making API calls that will hold authentication data

headersAPI = {
    'accept': 'application/json',
    'Authorization': 'Bearer '+j['access_token'],
}

### Usage of parameters defined in your API
params = (
    ('offset', '0'),
    ('limit', '20'),
)

# Making sample API call with authentication and API parameters data

response = requests.get('https://somedomain.test.com/api/Users/Year/2020/Workers', headers=headersAPI, params=params, verify=True)
api_response = response.json()