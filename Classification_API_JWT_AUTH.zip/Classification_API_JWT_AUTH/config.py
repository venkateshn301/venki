import secrets;
sec_key = secrets.token_urlsafe(12)

# https://pythonise.com/series/learning-flask/flask-configuration-files

class Config(object):
    DEBUG = False
    TESTING = False
    SECRET_KEY = sec_key


class ProductionConfig(Config):
    DEBUG = True


class DevelopmentConfig(Config):
    DEBUG = True
    TESTING = True


class TestingConfig(Config):
    DEBUG = True


